package com.curso.service;


import com.curso.repository.RecursoRepository;
import com.curso.repository.ReservaRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class ReservaService {

    private ReservaRepository reservaRepository;
    private RecursoRepository recursoRepository;

    public ReservaService(ReservaRepository reservaRepository) {
        this.reservaRepository = reservaRepository;
    }

    public boolean checkFechaReserva(LocalDate fechaInicio, LocalDate fechaFin){
        return fechaInicio.isBefore(fechaFin);
    }

}
